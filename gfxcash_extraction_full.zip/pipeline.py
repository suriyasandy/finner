
import yaml
from extractors.file_loader import load_and_normalize
from matchers.gazetteer_builder import build_gazetteers_from_csv
from matchers.matcher import extract_with_gazetteers
from matchers.regex_patterns import patterns
from nlp.ai_fallback import run_ai_fallback

def run_pipeline(file_path, csv_path, config_path):
    with open(config_path) as f:
        cfg = yaml.safe_load(f)

    gazetteers, alias_maps = build_gazetteers_from_csv(csv_path, config_path)
    text = load_and_normalize(file_path)

    gaz_matches = extract_with_gazetteers(text, gazetteers, alias_maps)

    pattern_matches = {}
    for name, rx in patterns.items():
        matches = []
        for m in rx.finditer(text):
            matches.append({
                "value": m.group(0),
                "raw": m.group(0),
                "span": (m.start(), m.end()),
                "confidence": 0.90
            })
        pattern_matches[name] = matches

    resolved_fields = set(gaz_matches.keys()) | set(pattern_matches.keys())
    unresolved = []
    for group in ["gazetteer_fields", "pattern_fields", "derived_fields", "fallback_fields"]:
        if isinstance(cfg[group], dict):
            for field_list in cfg[group].values():
                for field in field_list:
                    if field not in resolved_fields:
                        unresolved.append(field)
        else:
            for field in cfg[group]:
                if field not in resolved_fields:
                    unresolved.append(field)

    ai_results = run_ai_fallback(text, unresolved)

    return {"gazetteer": gaz_matches, "patterns": pattern_matches, "ai_fallback": ai_results}
