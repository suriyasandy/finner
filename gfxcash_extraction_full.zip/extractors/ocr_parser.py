
import easyocr
import re

def extract_text_from_image(image_path):
    reader = easyocr.Reader(['en'], model_storage_directory='./models')
    ocr_results = reader.readtext(image_path, detail=0)
    text = "\n".join(ocr_results)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()
