
import re

def extract_plain_tables(txt_file):
    if txt_file.endswith(".txt"):
        with open(txt_file, 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        text = txt_file

    text = re.sub(r'\t+', ' | ', text)
    text = re.sub(r' {2,}', ' | ', text)
    return text.strip()
