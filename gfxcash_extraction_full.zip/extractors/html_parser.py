
from bs4 import BeautifulSoup

def extract_html_tables(html_file):
    with open(html_file, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f, 'html.parser')

    all_text = []
    for table in soup.find_all('table'):
        for row in table.find_all('tr'):
            cells = [cell.get_text(strip=True) for cell in row.find_all(['td', 'th'])]
            all_text.append(" | ".join(cells))
    plain_text = soup.get_text(separator=" ", strip=True)
    all_text.append(plain_text)
    return "\n".join(all_text)
