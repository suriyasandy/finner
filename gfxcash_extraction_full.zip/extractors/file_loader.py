
import mimetypes
from .html_parser import extract_html_tables
from .table_parser import extract_plain_tables
from .ocr_parser import extract_text_from_image
from .pdf_parser import extract_text_from_pdf

def load_and_normalize(file_path):
    mime_type, _ = mimetypes.guess_type(file_path)

    if mime_type == "text/html":
        return extract_html_tables(file_path)
    elif mime_type in ["image/jpeg", "image/png"]:
        return extract_text_from_image(file_path)
    elif mime_type == "application/pdf":
        return extract_text_from_pdf(file_path)
    elif mime_type in ["text/plain", None]:
        return extract_plain_tables(file_path)
    else:
        raise ValueError(f"Unsupported file type: {mime_type}")
