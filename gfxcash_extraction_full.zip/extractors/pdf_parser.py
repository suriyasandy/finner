
import pdfplumber

def extract_text_from_pdf(pdf_path):
    all_text = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            table = page.extract_table()
            if table:
                for row in table:
                    all_text.append(" | ".join(cell or "" for cell in row))
            else:
                all_text.append(page.extract_text() or "")
    return "\n".join(all_text).strip()
