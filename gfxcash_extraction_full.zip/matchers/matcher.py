
from collections import defaultdict
from .fuzzy_match import fuzzy_canonicalize

def canonicalize(raw, alias_map, candidates):
    canon = alias_map.get(raw.lower())
    if canon:
        return canon, 0.95
    canon, score = fuzzy_canonicalize(raw, candidates)
    return canon, score

def extract_with_gazetteers(text, gazetteers, alias_maps):
    results = defaultdict(list)
    for field, pattern in gazetteers.items():
        candidates = list(alias_maps.get(field, {}).values())
        for match in pattern.finditer(text):
            raw_val = match.group(0)
            canon_val, conf = canonicalize(raw_val, alias_maps.get(field, {}), candidates)
            results[field].append({
                "value": canon_val,
                "raw": raw_val,
                "span": (match.start(), match.end()),
                "confidence": conf
            })
    return dict(results)
