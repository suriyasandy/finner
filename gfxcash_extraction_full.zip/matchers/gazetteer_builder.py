
import pandas as pd
import re
import yaml

def compile_gazetteer_regex(values):
    escaped = [re.escape(v) for v in sorted(set(values), key=len, reverse=True)]
    return re.compile(rf"(?<!\w)({'|'.join(escaped)})(?!\w)", re.IGNORECASE)

def build_alias_map(values):
    alias_map = {}
    for v in values:
        alias_map[v.lower()] = v
        alias_map[v.replace(" ", "").lower()] = v
    return alias_map

def build_gazetteers_from_csv(csv_path, config_path):
    with open(config_path) as f:
        cfg = yaml.safe_load(f)

    df = pd.read_csv(csv_path)
    gazetteers = {}
    alias_maps = {}

    for field in cfg["gazetteer_fields"]:
        if field in df.columns:
            values = df[field].dropna().astype(str).unique().tolist()
            gazetteers[field] = compile_gazetteer_regex(values)
            alias_maps[field] = build_alias_map(values)

    return gazetteers, alias_maps
