
from rapidfuzz import fuzz, process

def fuzzy_canonicalize(raw, candidates, threshold=85):
    if not raw or not candidates:
        return raw, 0
    best_match, score, _ = process.extractOne(raw, candidates, scorer=fuzz.ratio)
    if score >= threshold:
        return best_match, score / 100.0
    return raw, score / 100.0
