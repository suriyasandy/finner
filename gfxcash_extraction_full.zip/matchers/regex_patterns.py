
import re

patterns = {
    "date": re.compile(r"\b\d{4}[-/]\d{2}[-/]\d{2}|\d{2}[-/]\d{2}[-/]\d{4}\b"),
    "percent": re.compile(r"-?\d+(?:\.\d+)?\s*%|-?\d+(?:\.\d+)?\s*percent", re.IGNORECASE),
    "amount_ccy": re.compile(r"\b([A-Z]{3})\s?\d{1,3}(?:,\d{3})*(?:\.\d+)?\b|\b\d{1,3}(?:,\d{3})*(?:\.\d+)?\s?([A-Z]{3})\b"),
    "currency": re.compile(r"\b[A-Z]{3}\b")
}
