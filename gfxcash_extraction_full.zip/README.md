# GFXCASH Multi-format Extraction Pipeline
