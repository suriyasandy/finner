
def run_ai_fallback(text, fields):
    results = {}
    for field in fields:
        question = f"What is the {field.replace('_', ' ')}?"
        value, confidence, span = call_mrc_model(text, question)
        if value:
            results[field] = [{
                "value": value,
                "raw": value,
                "span": span,
                "confidence": confidence
            }]
    return results

def call_mrc_model(context, question):
    return None, None, None
