import argparse, json, yaml, os
from pipeline.extractors.parser import normalize_input
from pipeline.gazetteer import load_gazetteers
from pipeline.matchers.regex_patterns import load_patterns
from pipeline.matchers.matcher import extract_with_gazetteers
from pipeline.regex_anchored import anchored_regex
from pipeline.validator import validate_and_adjust
from pipeline.resolver import resolve_candidates
from pipeline.grouper import group_by_trade
from pipeline.summarize import summarize

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', required=True, help='Path to .msg/.html/.txt/.pdf/.image')
    ap.add_argument('--product', default='GFXCASH', help='Product code (uses product gazetteer)')
    ap.add_argument('--settings', default='config/settings.yaml', help='Path to settings.yaml')
    ap.add_argument('--out', default='results/output.json', help='Output JSON path')
    args = ap.parse_args()

    settings = yaml.safe_load(open(args.settings, 'r', encoding='utf-8'))
    paths = settings['paths']
    windows = settings['windows']
    modes = settings['modes']

    text = normalize_input(args.file)

    gpath_common = paths['common_gazetteer']
    gpath_prod = paths['product_gazetteer']
    gaz, alias = load_gazetteers(gpath_common, gpath_prod)

    gaz_hits = extract_with_gazetteers(text, gaz, alias)

    anchors = json.load(open(paths['anchors'], 'r', encoding='utf-8'))
    patterns = load_patterns(paths['patterns'])
    rx_hits = anchored_regex(
        text, patterns, anchors,
        anchor_window=windows['anchor_chars'],
        strict_no_generic=modes.get('strict_no_generic_regex', False)
    )

    candidates = {}
    for d in (gaz_hits, rx_hits):
        for k, v in d.items():
            candidates.setdefault(k, []).extend(v)

    candidates = validate_and_adjust(candidates)
    fields = resolve_candidates(candidates)
    trades = group_by_trade(text, fields, anchor_field='trade_id', fallback_anchor='execution_key', proximity_window=windows['grouping_chars'])

    summary_text = ''
    summ_cfg = settings.get('summarization', {})
    if summ_cfg.get('enabled', False):
        summary_text = summarize(text, fields, max_sentences=summ_cfg.get('max_sentences', 5), method=summ_cfg.get('method', 'extractive'))

    out = {
        'product': settings['product'],
        'overall_trust': round(sum(v['final_confidence'] for v in fields.values())/max(1,len(fields)), 3),
        'fields': fields,
        'trades': trades,
        'summary': summary_text
    }

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    json.dump(out, open(args.out, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
    print(f"Wrote {args.out}")

if __name__ == '__main__':
    main()
