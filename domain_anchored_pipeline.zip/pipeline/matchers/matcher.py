from collections import defaultdict

def canonicalize(raw, alias_map):
    canon = alias_map.get(raw.lower())
    if canon: return canon, 0.95
    return raw, 0.92

def extract_with_gazetteers(text, gazetteers, alias_maps):
    results = defaultdict(list)
    for field, pattern in gazetteers.items():
        alias_map = alias_maps.get(field, {})
        for m in pattern.finditer(text):
            raw = m.group(0)
            canon, conf = canonicalize(raw, alias_map)
            results[field].append({
                'field': field, 'value': canon, 'raw': raw,
                'span': (m.start(), m.end()), 'confidence': conf,
                'method': 'gazetteer_exact' if conf >= 0.93 else 'gazetteer_list'
            })
    return dict(results)
