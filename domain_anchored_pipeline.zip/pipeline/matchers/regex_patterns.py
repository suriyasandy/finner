import json, re

def load_patterns(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return {
        'trade_id': re.compile(data['trade_id']),
        'date': re.compile(data['date']),
        'percent': re.compile(data['percent'], re.IGNORECASE),
        'amount_ccy': re.compile(data['amount_ccy']),
        'currency': re.compile(data['currency']),
    }
