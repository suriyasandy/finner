from typing import Dict, List

def _state(score: float) -> str:
    if score >= 0.90: return 'auto_accept'
    if score >= 0.70: return 'needs_review'
    return 'likely_wrong'

def resolve_candidates(candidates: Dict[str, List[dict]]) -> Dict[str, dict]:
    fields = {}
    for field, hits in candidates.items():
        if not hits: continue
        counts = {}
        for h in hits:
            counts[h['value']] = counts.get(h['value'], 0) + 1
        boosted = []
        for h in hits:
            b = 0.05 if counts.get(h['value'], 0) >= 2 else 0.0
            boosted.append({**h, 'confidence': min(1.0, h['confidence'] + b)})
        best = max(boosted, key=lambda x: x['confidence'])
        fields[field] = {
            'value': best['value'],
            'final_confidence': round(best['confidence'], 3),
            'state': _state(best['confidence']),
            'method': best['method'],
            'evidence': sorted(boosted, key=lambda x: x['confidence'], reverse=True)[:5]
        }
    return fields
