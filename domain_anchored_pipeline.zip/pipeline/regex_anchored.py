import re
from typing import Dict, List

def _find_anchor_positions(text: str, terms):
    low = text.lower(); pos = []
    for t in terms:
        t = t.lower(); start = 0
        while True:
            i = low.find(t, start)
            if i < 0: break
            pos.append(i); start = i + len(t)
    return pos

def anchored_regex(text: str, patterns: Dict[str, re.Pattern], anchors: Dict[str, List[str]], anchor_window=80, strict_no_generic=False):
    candidates = {}
    matches = {
        'date': [(m.start(), m.end(), m.group(0)) for m in patterns['date'].finditer(text)],
        'percent': [(m.start(), m.end(), m.group(0)) for m in patterns['percent'].finditer(text)],
        'amount_ccy': [(m.start(), m.end(), m.group(0)) for m in patterns['amount_ccy'].finditer(text)],
        'currency': [(m.start(), m.end(), m.group(0)) for m in patterns['currency'].finditer(text)],
        'trade_id': [(m.start(), m.end(), m.group(0)) for m in patterns['trade_id'].finditer(text)],
    }

    field_to_kind = {
        'business_date': 'date',
        'trade_date': 'date',
        'settlement_date': 'date',
        'market_rate_datetime': 'date',
        'deviation_percent': 'percent',
        'base_threshold_percent': 'percent',
        'orig_threshold_percent': 'percent',
        'pnl_amount': 'amount_ccy',
        'commission_amount': 'amount_ccy',
        'base_currency_cd': 'currency',
        'orig_currency_cd': 'currency',
        'trade_id': 'trade_id',
        'execution_key': 'trade_id'
    }

    for field, kind in field_to_kind.items():
        cand = []
        aps = _find_anchor_positions(text, anchors.get(field, [field.replace('_',' ')]))
        if aps:
            for s,e,val in matches[kind]:
                d = min(abs(s - ap) for ap in aps)
                if d <= anchor_window:
                    cand.append({
                        'field': field, 'value': val, 'raw': val,
                        'span': (s,e), 'confidence': 0.93, 'method': 'regex_anchored'
                    })
        elif not strict_no_generic:
            for s,e,val in matches[kind]:
                cand.append({
                    'field': field, 'value': val, 'raw': val,
                    'span': (s,e), 'confidence': 0.80, 'method': 'regex_generic'
                })
        if cand:
            candidates.setdefault(field, []).extend(cand)
    return candidates
