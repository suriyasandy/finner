import re
from typing import Tuple, List, Dict, Any

def _line_blocks(text: str) -> List[Tuple[int,int]]:
    blocks = []
    start = 0
    for m in re.finditer(r'\n+', text):
        blocks.append((start, m.start())); start = m.end()
    blocks.append((start, len(text)))
    merged = []
    for b in blocks:
        if not merged: merged.append(b); continue
        if b[1]-b[0] < 20:
            prev = merged.pop(); merged.append((prev[0], b[1]))
        else:
            merged.append(b)
    return merged

def group_by_trade(text: str, fields: Dict[str, dict], anchor_field='trade_id', fallback_anchor='execution_key', proximity_window=300):
    anchors = fields.get(anchor_field) or fields.get(fallback_anchor)
    if not anchors: return []
    value = anchors['value']
    anchor_evs = anchors.get('evidence', [])
    anchor_spans = [tuple(ev.get('span',(0,0))) for ev in anchor_evs]
    blocks = _line_blocks(text)

    card = {
        anchor_field: value,
        'entities': {},
        'evidence': [],
        'score': 0.0
    }
    for sp in anchor_spans:
        s,e = sp; snip = text[max(0,s-40):min(len(text), e+40)]
        card['evidence'].append({'field': anchor_field, 'value': value, 'span': sp, 'snippet': snip, 'method': 'anchor', 'conf': 1.0})

    scores = []
    for field, info in fields.items():
        if field == anchor_field: continue
        val = info.get('value'); conf = info.get('final_confidence', 0.0)
        evs = info.get('evidence', [])
        best = max(evs, key=lambda x: x.get('confidence',0.0)) if evs else {'span': (0,0), 'snippet': '', 'method': info.get('method',''), 'confidence': conf}
        cand_span = tuple(best.get('span',(0,0)))

        if not anchor_spans: continue
        dists = [abs(cand_span[0]-aspan[0]) for aspan in anchor_spans]
        i = min(range(len(dists)), key=lambda k: dists[k])
        if dists[i] > proximity_window:
            continue

        card['entities'][field] = val
        card['evidence'].append({'field': field, 'value': val, 'span': cand_span, 'snippet': best.get('snippet',''), 'method': best.get('method',''), 'conf': best.get('confidence', conf)})
        scores.append(conf)

    card['score'] = round(sum(scores)/max(1,len(scores)), 3)
    return [card]
