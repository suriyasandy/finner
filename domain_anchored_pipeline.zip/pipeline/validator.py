from datetime import datetime

def _parse_date(s):
    for fmt in ('%Y-%m-%d','%d/%m/%Y','%m/%d/%Y','%Y/%m/%d'):
        try: return datetime.strptime(s, fmt)
        except Exception: pass
    return None

def validate_and_adjust(candidates: dict):
    for field, hits in candidates.items():
        for h in hits:
            if 'date' in field:
                d = _parse_date(h['value'])
                if d: h['confidence'] = min(1.0, h['confidence'] + 0.02)
            if field.endswith('_amount'):
                try:
                    base = h['value'].replace(',', '')
                    parts = base.split()
                    num = parts[0] if parts else base
                    float(num)
                    h['confidence'] = min(1.0, h['confidence'] + 0.02)
                except Exception:
                    h['confidence'] = max(0.0, h['confidence'] - 0.05)
    return candidates
