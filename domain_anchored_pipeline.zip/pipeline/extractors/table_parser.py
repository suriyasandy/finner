from bs4 import BeautifulSoup
import re

def _clean_html_for_msg(html):
    if not html:
        return ''
    if isinstance(html, bytes):
        try:
            html = html.decode('utf-8', errors='ignore')
        except Exception:
            html = html.decode('latin-1', errors='ignore')
    html = re.sub(r'<!--\[if.*?endif\]-->', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<xml>.*?</xml>', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<br\s*/?>', ' ', html, flags=re.IGNORECASE)
    return html

def _cell_text(td) -> str:
    txt = td.get_text(' ', strip=True)
    txt = re.sub(r'\xa0', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt

def extract_html_tables_as_text_from_html(html_body: str) -> str:
    if not html_body:
        return ''
    html = _clean_html_for_msg(html_body)

    try:
        import pandas as pd
        tables = pd.read_html(html)
        lines = []
        for df in tables:
            df.columns = [str(c).strip() for c in df.columns]
            for _, row in df.iterrows():
                kv = []
                for k, v in row.items():
                    v_str = '' if (pd.isna(v)) else str(v).strip()
                    if v_str != '':
                        kv.append(f"{k}: {v_str}")
                if kv:
                    lines.append(', '.join(kv))
        if lines:
            return '\n'.join(lines)
    except Exception:
        pass

    soup = BeautifulSoup(html, 'html.parser')
    lines = []
    for table in soup.find_all('table'):
        rows = table.find_all('tr')
        if not rows: continue

        header_row = next((r for r in rows if r.find_all('th')), rows[0])
        headers = [_cell_text(c) for c in header_row.find_all(['th','td']) if _cell_text(c)]
        if not headers:
            n = len([*rows[1].find_all(['td','th'])]) if len(rows) > 1 else 0
            headers = [f"COL{i+1}" for i in range(n)]

        for r in rows:
            if r == header_row: continue
            vals = [_cell_text(c) for c in r.find_all(['td','th'])]
            if not any(vals): continue
            if len(vals) < len(headers): vals += [''] * (len(headers)-len(vals))
            elif len(vals) > len(headers): vals = vals[:len(headers)]
            row_dict = dict(zip(headers, vals))
            kv = [f"{k}: {v}" for k, v in row_dict.items() if v != '']
            if kv:
                lines.append(', '.join(kv))
    return '\n'.join(lines)
