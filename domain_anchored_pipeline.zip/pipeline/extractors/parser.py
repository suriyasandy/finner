import mimetypes, os, re
from .table_parser import extract_html_tables_as_text_from_html
from .pdf_parser import extract_text_from_pdf
from .ocr_parser import extract_text_from_image

def normalize_input(path_or_html: str) -> str:
    if isinstance(path_or_html, str) and ('<html' in path_or_html.lower() or '<table' in path_or_html.lower()):
        return extract_html_tables_as_text_from_html(path_or_html)

    mime, _ = mimetypes.guess_type(path_or_html)
    if mime == 'text/html':
        with open(path_or_html, 'r', encoding='utf-8', errors='ignore') as f:
            return extract_html_tables_as_text_from_html(f.read())
    if mime == 'application/pdf':
        return extract_text_from_pdf(path_or_html)
    if mime in ['image/jpeg','image/png','image/webp','image/jpg']:
        return extract_text_from_image(path_or_html)
    if path_or_html.lower().endswith('.msg'):
        return extract_from_msg(path_or_html)

    try:
        with open(path_or_html, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception:
        return ''

def extract_from_msg(msg_path: str) -> str:
    text_parts = []
    try:
        import extract_msg
        msg = extract_msg.Message(msg_path)
        html = msg.htmlBody or ''
        body = msg.body or ''
        if html:
            text_parts.append(extract_html_tables_as_text_from_html(html))
        elif body:
            text_parts.append(body)

        for att in msg.attachments:
            name = getattr(att, 'longFilename', None) or getattr(att, 'shortFilename', None) or 'attachment'
            data = att.data
            if not data: continue
            tmp = os.path.join(os.path.dirname(msg_path), f'__att__{name}')
            with open(tmp, 'wb') as f: f.write(data)
            try:
                lower = name.lower()
                if lower.endswith(('.png','.jpg','.jpeg','.webp')):
                    text_parts.append(extract_text_from_image(tmp))
                elif lower.endswith('.pdf'):
                    text_parts.append(extract_text_from_pdf(tmp))
                elif lower.endswith('.msg'):
                    text_parts.append(extract_from_msg(tmp))  # one level
            finally:
                try: os.remove(tmp)
                except Exception: pass

        full = '\n'.join(t for t in text_parts if t)
        segments = re.split(r'(?:^|\n)(?:From:|Sent:|On .*wrote:)', full, flags=re.IGNORECASE)
        if len(segments) > 1:
            full = '\n\n'.join(s.strip() for s in segments if s.strip())
        return full
    except Exception:
        return ''
