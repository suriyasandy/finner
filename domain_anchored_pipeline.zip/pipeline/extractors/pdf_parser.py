def extract_text_from_pdf(path: str) -> str:
    try:
        import pdfplumber
        lines = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ''
                if text: lines.append(text)
                try:
                    tables = page.extract_tables() or []
                    for tbl in tables:
                        if len(tbl) >= 2:
                            headers = [str(x or '').strip() for x in tbl[0]]
                            for row in tbl[1:]:
                                kv = []
                                for k, v in zip(headers, row):
                                    v = (v or '').strip()
                                    if v:
                                        kv.append(f"{k}: {v}")
                                if kv:
                                    lines.append(', '.join(kv))
                except Exception:
                    pass
        return '\n'.join(lines)
    except Exception:
        return ''
