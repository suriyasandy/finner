def extract_text_from_image(path: str) -> str:
    try:
        import easyocr
        reader = easyocr.Reader(['en'], gpu=False)
        result = reader.readtext(path, detail=0, paragraph=True)
        return '\n'.join(result) if result else ''
    except Exception:
        return ''
