"""
Summarization hook.

- extractive: sentence scoring by keyword overlap with extracted entities
- llm: placeholder for future integration (kept offline-safe)
"""

def summarize(text: str, entities: dict, max_sentences: int = 5, method: str = "extractive") -> str:
    if not text.strip():
        return ""

    if method == "extractive":
        return _extractive_summary(text, entities, max_sentences)
    elif method == "llm":
        return _llm_summary_stub(text, entities, max_sentences)
    else:
        return ""

def _extractive_summary(text: str, entities: dict, max_sentences: int):
    import re
    sentences = re.split(r'(?<=[.!?])\s+', text)
    if not sentences:
        return ""

    keywords = set()
    for val in entities.values():
        if isinstance(val, dict):
            val = val.get("value", "")
        if isinstance(val, str):
            keywords.update(re.findall(r"\b\w+\b", val.lower()))

    scored = []
    for sent in sentences:
        words = re.findall(r"\b\w+\b", sent.lower())
        score = sum(1 for w in words if w in keywords)
        scored.append((score, sent.strip()))

    top_sents = [s for _, s in sorted(scored, key=lambda x: x[0], reverse=True) if s][:max_sentences]
    return " ".join(top_sents)

def _llm_summary_stub(text: str, entities: dict, max_sentences: int):
    return "[LLM summarization not implemented in offline mode]"
