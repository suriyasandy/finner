
# Outlook .MSG Parser Pro (offline-friendly)

Parses `.msg` files including:
- HTML & plaintext bodies (sanitized + text conversion)
- Inline/embedded images (CID) → saved and referenced in HTML
- Attachments (images, pdf, csv/xlsx, etc.)
- HTML table extraction & ASCII/plaintext table detection
- OCR on image attachments (EasyOCR or Tesseract if available)

## Install
```
pip install -r requirements.txt
# optional:
#   pip install striprtf   # for RTF → text (rtf_utils)
#   pip install easyocr    # if you have local wheels
# also install system tesseract if you use pytesseract
```

## Use
```
python demo_parse.py --msg /path/to/email.msg --out outputs
```
Outputs structured JSON and saves attachments.

## Integrate
Import `parse_msg_file_categorized` from `msgkit.msg_parser` and call with a path and output dir.
