
import json, os, argparse
from msgkit.msg_parser import parse_msg_file_categorized

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--msg", required=True, help="Path to .msg file")
    ap.add_argument("--out", default="outputs", help="Output directory")
    args = ap.parse_args()

    result = parse_msg_file_categorized(args.msg, out_dir=args.out)
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "parsed.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("Done. Saved JSON to", os.path.join(args.out, "parsed.json"))
    print("Attachments saved under", os.path.join(args.out, "attachments"))

if __name__ == "__main__":
    main()
