
from typing import List, Dict, Any
import pandas as pd
from bs4 import BeautifulSoup
import re

def _df_to_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    df = df.copy()
    if all(isinstance(c, (int, float)) for c in df.columns) and len(df)>0:
        first = df.iloc[0]
        if all(isinstance(x, str) for x in first):
            df.columns = [str(x).strip() or f"COL_{i}" for i,x in enumerate(first)]
            df = df.iloc[1:]
    df = df.fillna("")
    return df.to_dict(orient="records")

def extract_tables_from_html(html: str):
    if not html:
        return []
    out = []
    try:
        tables = pd.read_html(html)
        for df in tables:
            out.append(_df_to_records(df))
    except Exception:
        soup = BeautifulSoup(html, "lxml")
        for t in soup.find_all("table"):
            rows = []
            headers = []
            thead = t.find("thead")
            if thead and thead.find_all("th"):
                headers = [th.get_text(strip=True) for th in thead.find_all("th")]
            for tr in t.find_all("tr"):
                cells = tr.find_all(["td","th"])
                if not cells: 
                    continue
                texts = [c.get_text(" ", strip=True) for c in cells]
                if not headers and tr.find_all("th"):
                    headers = texts
                    continue
                if headers and len(texts) < len(headers):
                    texts += [""]*(len(headers)-len(texts))
                if headers:
                    rows.append({headers[i] if i<len(headers) else f"COL_{i}": v for i,v in enumerate(texts)})
                else:
                    rows.append({f"COL_{i}": v for i,v in enumerate(texts)})
            if rows:
                out.append(rows)
    return out

def extract_plaintext_tables(text: str):
    if not text:
        return []
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
    tables = []
    i = 0
    while i < len(lines):
        line = lines[i]
        sep = None
        if "|" in line:
            sep = r"\|"
        elif "\t" in line:
            sep = "\t"
        elif re.search(r"\s{2,}", line):
            sep = r"\s{2,}"
        if not sep:
            i += 1
            continue
        block = [line]
        j = i+1
        while j < len(lines) and (re.search(sep, lines[j]) is not None):
            block.append(lines[j]); j += 1
        i = j
        rows = []
        for ln in block:
            parts = [p.strip() for p in re.split(sep, ln) if p.strip()!=""]
            rows.append(parts)
        if not rows: 
            continue
        headers = None
        if rows and all(not re.search(r"\d", c) for c in rows[0]):
            headers = [c or f"COL_{k}" for k,c in enumerate(rows[0])]
            data = rows[1:]
        else:
            data = rows
        recs = []
        for r in data:
            if headers:
                if len(r) < len(headers):
                    r += [""]*(len(headers)-len(r))
                recs.append({headers[k] if k < len(headers) else f"COL_{k}": v for k,v in enumerate(r)})
            else:
                recs.append({f"COL_{k}": v for k,v in enumerate(r)})
        if recs:
            tables.append(recs)
    return tables
