
import os
from typing import Dict, Any, List
import extract_msg
from .html_utils import sanitize_html, html_to_text, replace_cid_images_with_files
from .rtf_utils import rtf_to_plaintext
from .table_extractors import extract_tables_from_html, extract_plaintext_tables
from .attachments import save_attachment
from .ocr import ocr_image_bytes
from .pdf_utils import pdf_to_text
import pandas as pd

def _get_best_body(msg) -> Dict[str,str]:
    html = getattr(msg, "htmlBody", "") or ""
    body = getattr(msg, "body", "") or ""
    rtf = getattr(msg, "rtfBody", "") or ""
    text_from_html = html_to_text(html) if html else ""
    text_from_rtf = rtf_to_plaintext(rtf) if rtf else ""
    text_body = text_from_html or text_from_rtf or body or ""
    return {"html": html, "text": text_body}

def parse_msg_file_categorized(path: str, out_dir: str = "outputs") -> Dict[str, Any]:
    os.makedirs(out_dir, exist_ok=True)
    attach_dir = os.path.join(out_dir, "attachments")
    os.makedirs(attach_dir, exist_ok=True)

    msg = extract_msg.Message(path)
    subject = getattr(msg, "subject", "")
    sender = getattr(msg, "sender", "")
    to = getattr(msg, "to", "")
    cc = getattr(msg, "cc", "")
    date = getattr(msg, "date", "")

    bodies = _get_best_body(msg)
    html = sanitize_html(bodies["html"])
    text_body = bodies["text"]

    cid_to_path = {}
    attachments_meta: List[Dict[str, Any]] = []
    for att in msg.attachments:
        path_saved, size = save_attachment(att, attach_dir)
        content_id = getattr(att, "cid", None) or getattr(att, "contentId", None) or ""
        is_inline = bool(getattr(att, "isInline", False)) or bool(content_id)
        mime = getattr(att, "mimetype", "") or ""
        meta = {
            "filename": getattr(att, "longFilename", None) or getattr(att, "filename", None),
            "saved_path": path_saved,
            "size_bytes": size,
            "content_id": content_id.strip("<>") if content_id else "",
            "is_inline": is_inline,
            "mime": mime
        }
        if meta["content_id"]:
            cid_to_path[meta["content_id"]] = path_saved
        attachments_meta.append(meta)

    if cid_to_path:
        html = replace_cid_images_with_files(html, cid_to_path)

    html_tables = extract_tables_from_html(html)
    plaintext_tables = extract_plaintext_tables(text_body)

    ocr_results = []
    for meta in attachments_meta:
        fname = (meta.get("filename") or "").lower()
        if any(fname.endswith(ext) for ext in (".png",".jpg",".jpeg",".bmp",".tiff",".tif",".gif")):
            try:
                with open(meta["saved_path"], "rb") as f:
                    b = f.read()
                txt = ocr_image_bytes(b)
                if txt and txt.strip():
                    ocr_results.append({"image": meta["saved_path"], "text": txt})
            except Exception:
                pass

    pdf_texts = []
    for meta in attachments_meta:
        fname = (meta.get("filename") or "").lower()
        if fname.endswith(".pdf"):
            t = pdf_to_text(meta["saved_path"])
            if t:
                pdf_texts.append({"pdf": meta["saved_path"], "text": t})

    tabular_files = []
    for meta in attachments_meta:
        fname = (meta.get("filename") or "").lower()
        p = meta["saved_path"]
        try:
            if fname.endswith(".csv"):
                df = pd.read_csv(p, nrows=200)
                tabular_files.append({"path": p, "type": "csv", "records": df.fillna("").to_dict(orient="records")})
            elif fname.endswith((".xlsx",".xls")):
                sheets = pd.read_excel(p, sheet_name=None)
                sheets_rec = {name: df.head(200).fillna("").to_dict(orient="records") for name, df in sheets.items()}
                tabular_files.append({"path": p, "type": "excel", "sheets": sheets_rec})
        except Exception:
            pass

    return {
        "meta": {"subject": subject, "from": sender, "to": to, "cc": cc, "date": str(date)},
        "html_body": html,
        "text_body": text_body,
        "attachments": attachments_meta,
        "extracted": {
            "html_tables": html_tables,
            "plaintext_tables": plaintext_tables,
            "images_text": ocr_results,
            "pdf_text": pdf_texts,
            "tabular_attachments": tabular_files
        }
    }
