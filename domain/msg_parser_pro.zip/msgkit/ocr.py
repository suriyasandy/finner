
from typing import Optional
from PIL import Image
import io

def ocr_image_bytes(img_bytes: bytes) -> Optional[str]:
    try:
        import easyocr
        reader = easyocr.Reader(['en'])
        import numpy as np
        image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        arr = np.array(image)
        lines = reader.readtext(arr, detail=0, paragraph=True)
        text = "\n".join(lines)
        if text.strip():
            return text
    except Exception:
        pass
    try:
        import pytesseract
        image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        txt = pytesseract.image_to_string(image)
        if txt and txt.strip():
            return txt.strip()
    except Exception:
        pass
    return None
