
try:
    from striprtf.striprtf import rtf_to_text
except Exception:
    rtf_to_text = None

def rtf_to_plaintext(rtf: str):
    if not rtf or rtf_to_text is None:
        return None
    try:
        return rtf_to_text(rtf)
    except Exception:
        return None
