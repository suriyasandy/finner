
import os

def save_attachment(att, out_dir: str):
    name = getattr(att, "longFilename", None) or getattr(att, "filename", None) or "attachment.bin"
    name = os.path.basename(str(name))
    data = getattr(att, "data", None) or getattr(att, "payload", None) or b""
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name)
    with open(path, "wb") as f:
        f.write(data)
    return path, len(data)
