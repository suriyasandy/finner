
import pdfplumber

def pdf_to_text(path: str):
    try:
        with pdfplumber.open(path) as pdf:
            txt = []
            for page in pdf.pages:
                txt.append(page.extract_text() or "")
        return "\n".join(txt).strip()
    except Exception:
        return None
