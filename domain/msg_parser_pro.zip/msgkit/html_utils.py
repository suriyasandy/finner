
from bs4 import BeautifulSoup
import re

def sanitize_html(html: str) -> str:
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style"]):
        tag.decompose()
    return str(soup)

def html_to_text(html: str) -> str:
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    for br in soup.find_all("br"):
        br.replace_with("\n")
    for p in soup.find_all("p"):
        p.insert_before("\n")
    text = soup.get_text(" ")
    text = re.sub(r"\n\s*\n\s*", "\n\n", text)
    return text.strip()

def replace_cid_images_with_files(html: str, cid_to_path: dict) -> str:
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    for img in soup.find_all("img"):
        src = img.get("src","")
        if src.startswith("cid:"):
            cid = src[4:].strip("<>")
            if cid in cid_to_path:
                img["src"] = cid_to_path[cid]
    return str(soup)
